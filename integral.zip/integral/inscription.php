<?php
/*
 * Template name: Inscription
 *
 */
?>

<?php get_header();

global $wpdb;
if ($_POST)
{
    $username = $wpdb->escape($S_POST['username']);
    $email = $wpdb->escape($S_POST['email']);
    $password = $wpdb->escape($_POST['password']);
    
    
    $error = array();
    
    if (strpos($username, ' ') !==FALSE)
    {
        $error['username_space']="Username has Space";
    }
    if(empty($username)) {
        $error['username_empty'] = "needed username must";
    }
    
    if(username_exists($username)){
        $error['username_exists'] = "Username already exists";
    }
    if (!is_email($email))
    {
        $error['email_valid'] = "Email has no valid value";
    }
    if(email_exists($email))
    {
        $error['email_existence'] = "Email already exists";
    }
    
    if(strcmp($password == $confirmPassword)!==0)
    {
        $error['password'] = "Password didn't match";
    }
    
    if (count($error)==0){
        wp_create_user($username, $password, $email);
                echo "user created successfully";
                exit();
    } else {
        print_r($error);
    }
}

?>

<div class="spacer"></div>

<div class="container">

	<div class="row">

		<div class="<?php if ( is_active_sidebar( 'rightbar' ) ) : ?>col-md-8<?php else : ?>col-md-12<?php endif; ?>">

			<div class="content">
			
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			
			     <h2 class="entry-title"><?php the_title(); ?></h2>
			    
			     <div class="entry">

			       <?php register_user_form(); ?>

			     </div>

			     
			 </div>
			
			 <?php endwhile;?>

			 <?php endif; ?>
			

			</div>

		</div>

		<?php get_sidebar(); ?>

	</div>

</div>

<?php get_footer(); ?>