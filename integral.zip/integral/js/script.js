
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//$(function () {
//  $(document).scroll(function () {
//    var nav = $(".container-fluid");
//    nav.toggleClass('scrolled', $(this).scrollTop() > nav.height());
//  });
//});

jQuery(document).ready(function($){
  $(document).scroll(function () {
    var $nav = $(".navbar-fixed-top");
    $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
  });
});


// Vérifier que les données entrées dans le formulaire d'inscription sont correctes //

jQuery( document ).ready( function($) {
	$( '#register-user' ).on( 'submit', function(e) {

		$( this ).find( 'input:required' ).each( function() {
			// On vérifie si les input requis sont remplis
			if ( $( this ).val().trim() == '' ) {
				e.preventDefault();
				$( this ).addClass( 'error' );
			}
		} );

		$( this ).find( 'input[type="email"]' ).each( function() {
			// Regex pour vérifier le champ email
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if ( ! pattern.test( $( this ).val() ) ) {
				e.preventDefault();
				$( this ).addClass( 'error' );
			}
		} );

	} );

	// Toggle hidden password
	$( '#show-password' ).on( 'change', function() {
		if ( $( this ).is( ':checked' ) ) {
			changetype( $( '#pass-user' ), 'text' );
		} else {
			changetype( $( '#pass-user' ), 'password' );
		}
	} );
	
	// Cette fonction permet de changer un type text et type password
	// Se referer à http://codepen.io/CreativeJuiz/pen/cvyEi/
	// ... et https://gist.github.com/3559343 pour comprendre
	function changeType(x, type) {
		if(x.prop('type') == type)
			return x;
		try {
			return x.prop('type', type);
		} catch(e) {
			var html = $("<div>").append(x.clone()).html();
			var regex = '/type=(\")?([^\"\s]+)(\")?/';
			var tmp = $(html.match(regex) == null ?
				html.replace(">", ' type="' + type + '">') :
				html.replace(regex, 'type="' + type + '"') );
			tmp.data('type', x.data('type') );
			var events = x.data('events');
			var cb = function(events) {
				return function() {
					for(i in events)
					{
						var y = events[i];
						for(j in y)
							tmp.bind(i, y[j].handler);
					}
				}
			}(events);
			x.replaceWith(tmp);
			setTimeout(cb, 10);
			return tmp;
		}
	}
} );

jQuery( document ).ready( function($) {

	if ( $( '.message' ).length > 0 ) {
		setTimeout( function() {
			$( '.message' ).remove();
		}, 6000 );
	}

} );


// BOUTTON RETOUR VERS LE HAUT DE LA PAGE //

// When the user scrolls down 800px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 800 || document.documentElement.scrollTop > 800) {
        document.getElementById("buttonUP").style.display = "block";
    } else {
        document.getElementById("buttonUP").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document

function scrollToTop(scrollDuration) {
    var scrollStep = -window.scrollY / (scrollDuration / 15),
        scrollInterval = setInterval(function() {
            if (window.scrollY != 0) {
                window.scrollBy(0, scrollStep);
            } else {
                clearInterval(scrollInterval);
            }
        }, 15);
}