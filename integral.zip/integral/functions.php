<?php 
/**
 * integral functions and definitions
 */

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
* Enqueue Scripts.
*/
require get_template_directory() . '/inc/enqueue.php';

/**
 * Redux Framework Options.
 */
require get_template_directory() . '/inc/options.php';

/**
* Theme Welcome Page.
*/
require get_template_directory() . '/inc/welcome/theme-welcome.php';

/**
* Wordpress Bootstrap Nav Walker.
*/
require get_template_directory() . '/inc/wp_bootstrap_navwalker.php';

/**
 * Extras.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Wordpress Customizer.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Register Widgets.
 */
require get_template_directory() . '/inc/widgets.php';

/**
* Load WooCommerce Functions.
*/
require get_template_directory() . '/inc/woocommerce.php';

/**
* TGM Plugin Activation.
*/
require get_template_directory() . '/inc/tgm-plugin-activation.php';

/**
* Theme Demo Import functions.
*/
require get_template_directory() . '/inc/theme-demo-import.php';

/**
* Upgrade Notice
*/
require get_template_directory() . '/inc/upgrade/class-customize.php';

/**
* Review Notice
*/
require get_template_directory() . '/inc/reviews.php';

// Ajouter le lien pour récupérer le mot de passe, si l'utilisateur ne s'en souvient plus
 add_filter( 'login_form_bottom', 'lien_mot_de_passe_perdu' );
function lien_mot_de_passe_perdu( $formbottom ) {
	$formbottom .= '<a href="' . wp_lostpassword_url() . '">Mot de passe perdu ?</a>';
	return $formbottom;
}

function register_user_form() {
    
        echo '<div class="form-style-10">';
        echo '<h1>Pas encore membre ? Inscrivez-vous maintenant et bénéficiez de nos offres !</h1>';
        echo '<form action="' . admin_url( 'admin-post.php?action=nouvel_utilisateur' ) . '" method="post" id="register-user">';
        echo '<div class="section"><span>1</span>Nom &amp; Adresse</div>';
        echo '<div class="inner-wrap"><label for="nom-user">Nom <input type="text" name="username" id="nom-user" required /></label>';
        echo '<label>Prénom <input name="field2" type="text" /></label>';
        echo '<label>Adresse <textarea name="field3"></textarea></label>';
        echo '<label>Code postal <input name="field4" type="number" /></label>';
        echo '<label>Ville <input name="field5" type="text" /></label></div>';

        echo '<div class="section"><span>2</span>Email &amp; Téléphone</div>';
        echo '<div class="inner-wrap"><label>Email <input type="email" name="email" id="email-user" required /></label>';
        echo '<label>Téléphone <input name="field7" type="text" /></label></div>';

        echo '<div class="section"><span>3</span>Mot de passe</div>';
        echo '<div class="inner-wrap"><label>Mot de passe <input type="password" name="pass" id="pass-user" required /></label>';
        //echo '<label>Confirmer le mot de passe <input name="confirmPassword" type="password" /></label></div>';
        //echo '<input type="checkbox" id="show-password"><label for="show-password">Voir le mot de passe</label></p>';
        
        // Nonce (pour vérifier plus tard que l'action a bien été initié par l'utilisateur)
	wp_nonce_field( 'create-' . $_SERVER['REMOTE_ADDR'], 'user-front', false );
        
        echo '<div class="button-section"><input name="Sign Up" type="submit" />';
        //echo '<span class="privacy-policy">';
        //echo '<input name="field7" type="checkbox" />J\'accèpte les termes du service Masterdropship.</span>';
        echo '</div>';
        echo '</form></div>';

	// Enqueue de scripts qui vont nous permettre de vérifier les champs
	wp_enqueue_script( 'inscription-front' );
}

// Enregistrement de l'utilisateur
add_action( 'admin_post_nopriv_nouvel_utilisateur', 'ajouter_utilisateur' );
function ajouter_utilisateur() {
	// Vérifier le nonce (et n'exécuter l'action que s'il est valide)
	if( isset( $_POST['user-front'] ) && wp_verify_nonce( $_POST['user-front'], 'create-' . $_SERVER['REMOTE_ADDR'] ) ) {

		// Vérifier les champs requis
		if ( ! isset( $_POST['username'] ) || ! isset( $_POST['email'] ) || ! isset( $_POST['pass'] ) ) {
			wp_redirect( site_url( '/inscription/?message=not-user' ) );
			exit();
		}
		
		$nom = $_POST['username'];
		$email = $_POST['email'];
		$pass = $_POST['pass'];

		// Vérifier que l'user (email ou nom) n'existe pas
		if ( is_email( $email ) && ! username_exists( $nom )  && ! email_exists( $email ) ) {
			// Création de l'utilisateur
	        $user_id = wp_create_user( $nom, $pass, $email );
	        $user = new WP_User( $user_id );
	        // On lui attribue un rôle
	        $user->set_role( 'subscriber' );
	        // Envoie un mail de notification au nouvel utilisateur
	        wp_new_user_notification( $user_id, $pass );
	    } else {
	    	wp_redirect( site_url( '/inscription/?message=already-registered' ) );
			exit();
	    }

		// Connecter automatiquement le nouvel utilisateur
                $creds = array();
		$creds['user_login'] = $nom;
		$creds['user_password'] = $pass;
		$creds['remember'] = false;
		$user = wp_signon( $creds, false );

		// Redirection
		wp_redirect( site_url( '/?message=welcome' ) );
		exit();
	}
}
add_action( 'wp_enqueue_scripts', 'register_login_script' );
function register_login_script() {
	wp_register_script( 'inscription-front', get_template_directory_uri() . '/js/inscription.js', array( 'jquery' ), '1.0', true );
	wp_register_script( 'message', get_template_directory_uri() . '/js/message.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'jquery' );

	// Ce script sera chargé sur toutes les pages du site, afin d'afficher les messages d'erreur
	wp_enqueue_script( 'message' );
}

add_action( 'wp_footer', 'show_user_registration_message' );
function show_user_registration_message() {
	if ( isset( $_GET['message'] ) ) {
		$wrapper = '<div class="message">%s</div>';
		switch ( $_GET['message'] ) {
			case 'already-registred':
				echo wp_sprintf( $wrapper, 'Un utilisateur possède la même adresse.' );
				break;
			case 'not-user':
				echo wp_sprintf( $wrapper, 'Votre inscription a échouée.' );
				break;
			case 'user-updated':
				echo wp_sprintf( $wrapper, 'Votre profil a été mis à jour.' );
				break;
			case 'need-email':
				echo wp_sprintf( $wrapper, 'Votre profil \'a pas été mis à jour. L\'email doit être renseignée.' );
				break;
			case 'email-exist':
				echo wp_sprintf( $wrapper, 'Votre profil \'a pas été mis à jour. L\'adresse email est déjà utilisée.' );
				break;
			case 'welcome':
				echo wp_sprintf( $wrapper, 'Votre compte a été créé. Vous allez recevoir un email de confirmation.' );
				break;
			default :
		}
	}
}

add_action( 'current_screen', 'redirect_non_authorized_user' );
function redirect_non_authorized_user() {
	// Si t'es pas admin, tu vires
	if ( is_user_logged_in() && ! current_user_can( 'manage_options' ) ) {
		wp_redirect( home_url( '/' ) );
		exit();
	}
}

add_action( 'template_redirect', 'private_type_of_page' );
function private_type_of_page() {
	if ( is_page_template( 'member.php' ) && ! is_user_logged_in() ) {
		wp_redirect( wp_login_url() );
		exit();
	}
}